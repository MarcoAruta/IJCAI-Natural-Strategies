from src.natATLmodelChecking import process_data
import multiprocessing


def algorithm():
    #path = 'C:\\Users\\utente\\Desktop\\NatATLTool\\MemorylessNATATL\\Testing\\exampleModel1.txt'
    #formula = 'C:\\Users\\utente\\Desktop\\NatATLTool\\MemorylessNATATL\\Testing\\exampleFormula4.txt'
    #result = 'C:\\Users\\utente\\Desktop\\NatATLTool\\MemorylessNATATL\\Testing\\Result'

    model = 'C:\\Users\\utente\\Desktop\\Lavoro\\DSN\\Ticket Machine - Memoryless example\\TicketMachineV2.txt'
    formula = 'C:\\Users\\utente\\Desktop\\Lavoro\\DSN\\Ticket Machine - Memoryless example\\formula.txt'
    result = 'C:\\Users\\utente\\Desktop\\Lavoro\\DSN\\Ticket Machine - Memoryless example\\result.txt'

    #main function
    process_data(model, formula, result)

if __name__ == "__main__":
    process = multiprocessing.Process(target=algorithm)
    process.start()
    process.join(timeout=7200)  # Set timeout for tests to 7200 seconds (2 hours)

    if process.is_alive():
        print("The execution is still going after 2 hours....Terminating....Time is up! No solution found!")
        process.terminate()
        process.join()

