import matplotlib
matplotlib.use('TkAgg')
import matplotlib.pyplot as plt

def plot_execution_times(file_path):
    with open(file_path, 'r') as file:
        lines = file.readlines()

    # Extract execution times and convert them to floats
    times = [float(line.split(": ")[1].split(" ")[0]) for i, line in enumerate(lines) if (i + 1) % 3 == 0]

    # Plot the execution times
    plt.plot(times)
    total_time = sum(times)
    count = len(times)
    print(f"somma dei tempi: {total_time}, elementi: {count}")
    plt.ylabel('Execution Time (seconds)')
    plt.show()

plot_execution_times("C:\\Users\\lmfao\\Desktop\\Tesi\\TESTING\\Tool Analysis Testings\\12States5Agents.txt")